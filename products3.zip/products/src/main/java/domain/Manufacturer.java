package domain;

public class Manufacturer {
	 private Long id;
	    private String namecategory;

	    public Manufacturer() {
	    }

	    public Manufacturer(String namecategory) {
	        this.namecategory = namecategory;
	    }

	    public Manufacturer(long id, String namecategory) {
	        this.id = id;
	        this.namecategory = namecategory;
	    }

	    public Long getId() {
	        return id;
	    }

	    public void setId(long id) {
	        this.id = id;
	    }

	    public String getNamecategory() {
	        return namecategory;
	    }

	    public void setNamerole(String namerole) {
	        this.namecategory = namecategory;
	    }

	    @Override
	    public String toString() {
	        return "Category {" + "Id = " + id + ", NameCategory = " + namecategory + "}";
	    }
}
