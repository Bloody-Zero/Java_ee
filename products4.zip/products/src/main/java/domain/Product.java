package domain;

public class Product {
	private Long id;
	private String name;
	private String size;
	private Double weight;
	private Long manufacturerId;
	private Manufacturer manufacturer;

	public Product() {
	}

	public Product(String name, String size, Double weight, Manufacturer manufacturer) {
		this.name = name;
		this.size = size;
		this.weight = weight;
		this.manufacturer = manufacturer;
	}

	public Product(Long id, String name, String size, Double weight, Long manufacturerId, Manufacturer manufacturer) {
		this.id = id;
		this.name = name;
		this.size = size;
		this.weight = weight;
		this.manufacturerId = manufacturerId;
		this.manufacturer = manufacturer;
	}

	// Геттеры и сеттеры
	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getSize() {
		return size;
	}

	public void setSize(String size) {
		this.size = size;
	}

	public Double getWeight() {
		return weight;
	}

	public void setWeight(Double weight) {
		this.weight = weight;
	}

	public Long getManufacturerId() {
		return manufacturerId;
	}

	public void setManufacturerId(Long manufacturerId) {
		this.manufacturerId = manufacturerId;
	}

	public Manufacturer getManufacturer() {
		return manufacturer;
	}

	public void setManufacturer(Manufacturer manufacturer) {
		this.manufacturer = manufacturer;
	}

	@Override
	public String toString() {
		return "Product{" + "id=" + id + ", name='" + name + '\'' + ", size='" + size + '\'' + ", weight=" + weight
				+ ", manufacturerId=" + manufacturerId + ", manufacturer="
				+ (manufacturer != null ? manufacturer.getName() : "null") + '}';
	}
}