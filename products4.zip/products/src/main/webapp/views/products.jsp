<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<%@ page import="domain.Manufacturer"%>
<%@ page import="domain.Product"%>
<%@ page import="java.util.List"%>
<%@ page import="java.util.Arrays"%>

<%
Manufacturer m1 = new Manufacturer(1L, "ООО ТехноПром", "Россия", "Иванов И.И.", "+7-495-111-11-11");
Manufacturer m2 = new Manufacturer(2L, "ОАО АвтоПром", "Германия", "Петров П.П.", "+49-30-222-22-22");
List<Manufacturer> manufacturers = Arrays.asList(m1, m2);

Product p1 = new Product(1L, "Ноутбук", "15 дюймов", 2.5, 1L, m1);
Product p2 = new Product(2L, "Автомобиль", "Средний класс", 1500.0, 2L, m2);
List<Product> products = Arrays.asList(p1, p2);
%>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Товары</title>
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="css/bootstrap.min.css">
</head>
<body>
    <div class="container-fluid">
        <jsp:include page="/views/header.jsp" />
        <div class="container-fluid">
            <div class="row justify-content-start">
                <!-- Список товаров -->
                <div class="col-8 border bg-light px-4">
                    <h3>Список товаров</h3>
                    <table class="table">
                        <thead>
                            <tr>
                                <th scope="col">Код</th>
                                <th scope="col">Наименование</th>
                                <th scope="col">Размер</th>
                                <th scope="col">Вес (кг)</th>
                                <th scope="col">Производитель</th>
                                <th scope="col">Редактировать</th>
                                <th scope="col">Удалить</th>
                            </tr>
                        </thead>
                        <tbody>
                            <% for (Product product : products) { %>
                                <tr>
                                    <td><%= product.getId() %></td>
                                    <td><%= product.getName() %></td>
                                    <td><%= product.getSize() %></td>
                                    <td><%= product.getWeight() %></td>
                                    <td><%= product.getManufacturer().getName() %></td>
                                    <td width="20">
                                        <a href="#" role="button" class="btn btn-outline-primary">
                                            <img alt="Редактировать"  src="${pageContext.request.contextPath}/images/icon-edit.png" width="20" height="20">
                                        </a>
                                    </td>
                                    <td width="20">
                                        <a href="#" role="button" class="btn btn-outline-primary">
                                            <img alt="Удалить"  src="${pageContext.request.contextPath}/images/icon-delete.png" width="20" height="20">
                                        </a>
                                    </td>
                                </tr>
                            <% } %>
                        </tbody>
                    </table>
                </div>

                <!-- Форма добавления нового товара -->
                <div class="col-4 border px-4">
                    <form method="POST" action="">
                        <h3>Новый товар</h3>
                        <div class="mb-3">
                            <label for="inputName" class="form-label">Наименование</label>
                            <input type="text" name="name" class="form-control" id="inputName" required>
                        </div>
                        <div class="mb-3">
                            <label for="inputSize" class="form-label">Размер</label>
                            <input type="text" name="size" class="form-control" id="inputSize">
                        </div>
                        <div class="mb-3">
                            <label for="inputWeight" class="form-label">Вес (кг)</label>
                            <input type="number" step="0.01" name="weight" class="form-control" id="inputWeight">
                        </div>
                        <div class="mb-3">
                            <label for="inputManufacturer" class="form-label">Производитель</label>
                            <select name="manufacturerId" class="form-control" id="inputManufacturer">
                                <option value="">Выберите производителя</option>
                                <% for (Manufacturer manufacturer : manufacturers) { %>
                                    <option value="<%= manufacturer.getId() %>">
                                        <%= manufacturer.getName() %> (<%= manufacturer.getCountry() %>)
                                    </option>
                                <% } %>
                            </select>
                        </div>
                        <button type="submit" class="btn btn-primary">Добавить</button>
                    </form>
                </div>
            </div>
        </div>
        <jsp:include page="/views/footer.jsp" />
    </div>

    <!-- jQuery и Bootstrap JS -->
    <script src="js/jquery-3.6.4.js"></script>
    <script src="js/bootstrap.bundle.min.js"></script>
</body>
</html>