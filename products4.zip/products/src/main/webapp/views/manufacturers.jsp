<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<%@ page import="domain.Manufacturer"%>
<%@ page import="java.util.List"%>
<%@ page import="java.util.Arrays"%>

<%
Manufacturer m1 = new Manufacturer(1L, "ООО ТехноПром", "Россия", "Иванов И.И.", "+7-495-111-11-11");
Manufacturer m2 = new Manufacturer(2L, "ОАО АвтоПром", "Германия", "Петров П.П.", "+49-30-222-22-22");
Manufacturer m3 = new Manufacturer(3L, "ЗАО СтройМаш", "Китай", "Сидоров С.С.", "+86-10-333-33-33");
List<Manufacturer> manufacturers = Arrays.asList(m1, m2, m3);
%>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Производители</title>
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="css/bootstrap.min.css">
</head>
<body>
    <div class="container-fluid">
        <jsp:include page="/views/header.jsp" />
        <div class="container-fluid">
            <div class="row justify-content-start">
                <!-- Список производителей -->
                <div class="col-8 border bg-light px-4">
                    <h3>Список производителей</h3>
                    <table class="table">
                        <thead>
                            <tr>
                                <th scope="col">Код</th>
                                <th scope="col">Название</th>
                                <th scope="col">Страна</th>
                                <th scope="col">Контактное лицо</th>
                                <th scope="col">Телефон</th>
                                <th scope="col">Редактировать</th>
                                <th scope="col">Удалить</th>
                            </tr>
                        </thead>
                        <tbody>
                            <% for (Manufacturer manufacturer : manufacturers) { %>
                                <tr>
                                    <td><%= manufacturer.getId() %></td>
                                    <td><%= manufacturer.getName() %></td>
                                    <td><%= manufacturer.getCountry() %></td>
                                    <td><%= manufacturer.getContactPerson() %></td>
                                    <td><%= manufacturer.getPhone() %></td>
                                    <td width="20">
                                        <a href="#" role="button" class="btn btn-outline-primary">
                                            <img alt="Редактировать" src="${pageContext.request.contextPath}/images/icon-edit.png" width="20" height="20">
                                        </a>
                                    </td>
                                    <td width="20">
                                        <a href="#" role="button" class="btn btn-outline-primary">
                                            <img alt="Удалить"  src="${pageContext.request.contextPath}/images/icon-delete.png" width="20" height="20">
                                        </a>
                                    </td>
                                </tr>
                            <% } %>
                        </tbody>
                    </table>
                </div>

                <!-- Форма добавления нового производителя -->
                <div class="col-4 border px-4">
                    <form method="POST" action="">
                        <h3>Новый производитель</h3>
                        <div class="mb-3">
                            <label for="inputName" class="form-label">Название</label>
                            <input type="text" name="name" class="form-control" id="inputName" required>
                        </div>
                        <div class="mb-3">
                            <label for="inputCountry" class="form-label">Страна</label>
                            <input type="text" name="country" class="form-control" id="inputCountry" required>
                        </div>
                        <div class="mb-3">
                            <label for="inputContactPerson" class="form-label">Контактное лицо</label>
                            <input type="text" name="contactPerson" class="form-control" id="inputContactPerson">
                        </div>
                        <div class="mb-3">
                            <label for="inputPhone" class="form-label">Телефон</label>
                            <input type="text" name="phone" class="form-control" id="inputPhone">
                        </div>
                        <button type="submit" class="btn btn-primary">Добавить</button>
                    </form>
                </div>
            </div>
        </div>
        <jsp:include page="/views/footer.jsp" />
    </div>

    <!-- jQuery и Bootstrap JS -->
    <script src="js/jquery-3.6.4.js"></script>
    <script src="js/bootstrap.bundle.min.js"></script>
</body>
</html>