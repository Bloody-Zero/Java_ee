<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <!-- Настройка viewport -->
    <meta name="viewport" content="width=device-width, initial-scale=1">
</head>
<body>
    <!-- Header -->
    <nav class="navbar navbar-light bg-primary">
        <div class="container-fluid">
            <a href="${pageContext.request.contextPath}/">
                <img alt="Логотип" id="top-image" 
                     src="${pageContext.request.contextPath}/images/Products.png"  
                     width="80" height="80">
            </a>
            <h2>Управление товаром</h2>
        </div>
    </nav>
    <!-- /Header -->
</body>
</html>