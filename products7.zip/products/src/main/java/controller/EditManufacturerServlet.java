package controller;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import dao.ManufacturerDbDAO;
import domain.Manufacturer;
import exception.DAOException;

import java.io.IOException;

@WebServlet("/editManufacturer")
public class EditManufacturerServlet extends HttpServlet {
    
    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        String idStr = request.getParameter("id");
        
        if (idStr != null && !idStr.trim().isEmpty()) {
            try {
                Long id = Long.parseLong(idStr);
                ManufacturerDbDAO dao = new ManufacturerDbDAO();
                Manufacturer manufacturer = dao.findById(id);
                
                if (manufacturer != null) {
                    request.setAttribute("manufacturer", manufacturer);
                    request.getRequestDispatcher("/views/editManufacturer.jsp").forward(request, response);
                } else {
                    response.sendRedirect(request.getContextPath() + "/manufacturers?error=Производитель не найден");
                }
                
            } catch (DAOException e) {
                e.printStackTrace();
                response.sendRedirect(request.getContextPath() + "/manufacturers?error=Ошибка загрузки: " + e.getMessage());
            } catch (NumberFormatException e) {
                response.sendRedirect(request.getContextPath() + "/manufacturers?error=Неверный ID");
            }
        } else {
            response.sendRedirect(request.getContextPath() + "/manufacturers?error=ID не указан");
        }
    }
    
    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        try {
            // Получаем данные из формы
            Long id = Long.parseLong(request.getParameter("id"));
            String name = request.getParameter("name");
            String country = request.getParameter("country");
            String contactPerson = request.getParameter("contactPerson");
            String phone = request.getParameter("phone");
            
            // Обновляем производителя
            Manufacturer manufacturer = new Manufacturer();
            manufacturer.setId(id);
            manufacturer.setName(name);
            manufacturer.setCountry(country);
            manufacturer.setContactPerson(contactPerson);
            manufacturer.setPhone(phone);
            
            ManufacturerDbDAO dao = new ManufacturerDbDAO();
            dao.update(manufacturer);
            
            response.sendRedirect(request.getContextPath() + "/manufacturers?success=Производитель обновлен");
            
        } catch (Exception e) {
            e.printStackTrace();
            response.sendRedirect(request.getContextPath() + "/manufacturers?error=Ошибка обновления: " + e.getMessage());
        }
    }
}