package controller;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import dao.ManufacturerDbDAO;
import exception.DAOException;

import java.io.IOException;

@WebServlet("/deleteManufacturer")
public class DeleteManufacturerServlet extends HttpServlet {
    
    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        String idStr = request.getParameter("id");
        
        if (idStr != null && !idStr.trim().isEmpty()) {
            try {
                Long id = Long.parseLong(idStr);
                ManufacturerDbDAO dao = new ManufacturerDbDAO();
                dao.delete(id);
                
                // Перенаправляем обратно на страницу производителей
                response.sendRedirect(request.getContextPath() + "/manufacturers?success=Производитель удален");
                
            } catch (DAOException e) {
                e.printStackTrace();
                response.sendRedirect(request.getContextPath() + "/manufacturers?error=Ошибка удаления: " + e.getMessage());
            } catch (NumberFormatException e) {
                response.sendRedirect(request.getContextPath() + "/manufacturers?error=Неверный ID");
            }
        } else {
            response.sendRedirect(request.getContextPath() + "/manufacturers?error=ID не указан");
        }
    }
}