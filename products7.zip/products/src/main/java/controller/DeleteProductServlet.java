package controller;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import dao.ProductDbDAO;
import exception.DAOException;

import java.io.IOException;

@WebServlet("/deleteProduct")
public class DeleteProductServlet extends HttpServlet {
    
    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        String idStr = request.getParameter("id");
        
        if (idStr != null && !idStr.trim().isEmpty()) {
            try {
                Long id = Long.parseLong(idStr);
                ProductDbDAO dao = new ProductDbDAO();
                dao.delete(id);
                
                response.sendRedirect(request.getContextPath() + "/products?success=Товар удален");
                
            } catch (DAOException e) {
                e.printStackTrace();
                response.sendRedirect(request.getContextPath() + "/products?error=Ошибка удаления: " + e.getMessage());
            } catch (NumberFormatException e) {
                response.sendRedirect(request.getContextPath() + "/products?error=Неверный ID");
            }
        } else {
            response.sendRedirect(request.getContextPath() + "/products?error=ID не указан");
        }
    }
}