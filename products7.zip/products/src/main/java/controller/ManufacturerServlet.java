package controller;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import dao.ManufacturerDbDAO;
import dao.ProductDbDAO;
import domain.Manufacturer;
import domain.Product;
import exception.DAOException;

import java.io.IOException;
import java.util.List;

@WebServlet("/manufacturers")
public class ManufacturerServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        response.setContentType("text/html;charset=UTF-8");
        
        // ДОБАВЛЕНО: Обрабатываем сообщения из URL параметров
        String success = request.getParameter("success");
        String error = request.getParameter("error");
        if (success != null) {
            request.setAttribute("success", success);
        }
        if (error != null) {
            request.setAttribute("error", error);
        }
        
        try {
            loadData(request);
        } catch (DAOException e) {
            e.printStackTrace();
            request.setAttribute("error", "Ошибка при загрузке производителей: " + e.getMessage());
        }
        
        request.getRequestDispatcher("/views/manufacturers.jsp").forward(request, response);
    }
    
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        response.setContentType("text/html;charset=UTF-8");
        
        // ДОБАВЛЕНО: Обрабатываем сообщения из URL параметров
        String success = request.getParameter("success");
        String error = request.getParameter("error");
        if (success != null) {
            request.setAttribute("success", success);
        }
        if (error != null) {
            request.setAttribute("error", error);
        }
        
        try {
            // Обрабатываем добавление нового производителя
            String name = request.getParameter("name");
            String country = request.getParameter("country");
            String contactPerson = request.getParameter("contactPerson");
            String phone = request.getParameter("phone");
            
            if (name != null && !name.trim().isEmpty()) {
                Manufacturer manufacturer = new Manufacturer();
                manufacturer.setName(name);
                manufacturer.setCountry(country);
                manufacturer.setContactPerson(contactPerson);
                manufacturer.setPhone(phone);
                
                ManufacturerDbDAO dao = new ManufacturerDbDAO();
                dao.insert(manufacturer);
                
                request.setAttribute("success", "Производитель успешно добавлен!");
            }
            
            // Загружаем обновленные данные
            loadData(request);
            
        } catch (DAOException e) {
            e.printStackTrace();
            request.setAttribute("error", "Ошибка при добавлении производителя: " + e.getMessage());
        }
        
        request.getRequestDispatcher("/views/manufacturers.jsp").forward(request, response);
    }
    
    private void loadData(HttpServletRequest request) throws DAOException {
        System.out.println("=== НАЧАЛО ЗАГРУЗКИ ДАННЫХ ===");
        
        ProductDbDAO productDao = new ProductDbDAO();
        ManufacturerDbDAO manufacturerDao = new ManufacturerDbDAO();
        
        List<Product> products = productDao.findAll();
        List<Manufacturer> manufacturers = manufacturerDao.findAll();
        
        System.out.println("Загружено товаров: " + products.size());
        System.out.println("Загружено производителей: " + manufacturers.size());
        
        // Для отладки выводим содержимое
        for (Product p : products) {
            System.out.println("Товар: " + p.getName() + ", ID: " + p.getId());
        }
        for (Manufacturer m : manufacturers) {
            System.out.println("Производитель: " + m.getName() + ", ID: " + m.getId());
        }
        
        System.out.println("=== КОНЕЦ ЗАГРУЗКИ ДАННЫХ ===");
        
        request.setAttribute("products", products);
        request.setAttribute("manufacturers", manufacturers);
    }
}