package controller;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import dao.ManufacturerDbDAO;
import dao.ProductDbDAO;
import domain.Manufacturer;
import domain.Product;
import exception.DAOException;

import java.io.IOException;
import java.util.List;

@WebServlet("/products")
public class ProductServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        response.setContentType("text/html;charset=UTF-8");
        
        // ДОБАВЛЕНО: Обрабатываем сообщения из URL параметров
        String success = request.getParameter("success");
        String error = request.getParameter("error");
        if (success != null) {
            request.setAttribute("success", success);
        }
        if (error != null) {
            request.setAttribute("error", error);
        }
        
        try {
            // ВСЕГДА загружаем данные при GET-запросе
            loadData(request);
        } catch (DAOException e) {
            e.printStackTrace();
            request.setAttribute("error", "Ошибка при загрузке данных: " + e.getMessage());
        }
        
        request.getRequestDispatcher("/views/products.jsp").forward(request, response);
    }
    
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        response.setContentType("text/html;charset=UTF-8");
        
        // ДОБАВЛЕНО: Обрабатываем сообщения из URL параметров
        String success = request.getParameter("success");
        String error = request.getParameter("error");
        if (success != null) {
            request.setAttribute("success", success);
        }
        if (error != null) {
            request.setAttribute("error", error);
        }
        
        try {
            // 1. Обрабатываем добавление нового товара
            String name = request.getParameter("name");
            String size = request.getParameter("size");
            String weightStr = request.getParameter("weight");
            String manufacturerIdStr = request.getParameter("manufacturerId");
            
            if (name != null && !name.trim().isEmpty()) {
                // Создаем новый товар
                Product product = new Product();
                product.setName(name);
                product.setSize(size);
                
                if (weightStr != null && !weightStr.trim().isEmpty()) {
                    product.setWeight(Double.parseDouble(weightStr));
                }
                
                if (manufacturerIdStr != null && !manufacturerIdStr.trim().isEmpty()) {
                    product.setManufacturerId(Long.parseLong(manufacturerIdStr));
                    
                    // Загружаем производителя для связи
                    ManufacturerDbDAO manufacturerDao = new ManufacturerDbDAO();
                    Manufacturer manufacturer = manufacturerDao.findById(Long.parseLong(manufacturerIdStr));
                    product.setManufacturer(manufacturer);
                }
                
                // Сохраняем в БД
                ProductDbDAO productDao = new ProductDbDAO();
                productDao.insert(product);
                
                // Устанавливаем сообщение об успехе
                request.setAttribute("success", "Товар успешно добавлен!");
            }
            
            // 2. Загружаем обновленные данные
            loadData(request);
            
        } catch (DAOException | NumberFormatException e) {
            e.printStackTrace();
            request.setAttribute("error", "Ошибка при добавлении товара: " + e.getMessage());
        }
        
        // 3. Форвардим обратно на JSP
        request.getRequestDispatcher("/views/products.jsp").forward(request, response);
    }
    
    // Метод для загрузки данных (используется в doGet и doPost)
    private void loadData(HttpServletRequest request) throws DAOException {
        System.out.println("=== НАЧАЛО ЗАГРУЗКИ ДАННЫХ ===");
        
        ProductDbDAO productDao = new ProductDbDAO();
        ManufacturerDbDAO manufacturerDao = new ManufacturerDbDAO();
        
        List<Product> products = productDao.findAll();
        List<Manufacturer> manufacturers = manufacturerDao.findAll();
        
        System.out.println("Загружено товаров: " + products.size());
        System.out.println("Загружено производителей: " + manufacturers.size());
        
        // Для отладки выводим содержимое
        for (Product p : products) {
            System.out.println("Товар: " + p.getName() + ", ID: " + p.getId());
        }
        for (Manufacturer m : manufacturers) {
            System.out.println("Производитель: " + m.getName() + ", ID: " + m.getId());
        }
        
        System.out.println("=== КОНЕЦ ЗАГРУЗКИ ДАННЫХ ===");
        
        request.setAttribute("products", products);
        request.setAttribute("manufacturers", manufacturers);
    }
}