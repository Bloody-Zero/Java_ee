package controller;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import dao.ManufacturerDbDAO;
import dao.ProductDbDAO;
import domain.Manufacturer;
import domain.Product;
import exception.DAOException;

import java.io.IOException;
import java.util.List;

@WebServlet("/editProduct")
public class EditProductServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        response.setContentType("text/html;charset=UTF-8");
        
        String idStr = request.getParameter("id");
        
        if (idStr != null && !idStr.trim().isEmpty()) {
            try {
                Long id = Long.parseLong(idStr);
                
                // Загружаем товар для редактирования
                ProductDbDAO productDao = new ProductDbDAO();
                Product product = productDao.findById(id);
                
                // Загружаем список производителей для выпадающего списка
                ManufacturerDbDAO manufacturerDao = new ManufacturerDbDAO();
                List<Manufacturer> manufacturers = manufacturerDao.findAll();
                
                if (product != null) {
                    request.setAttribute("product", product);
                    request.setAttribute("manufacturers", manufacturers);
                    request.getRequestDispatcher("/views/editProduct.jsp").forward(request, response);
                } else {
                    response.sendRedirect(request.getContextPath() + 
                        "/products?error=Товар не найден");
                }
                
            } catch (DAOException e) {
                e.printStackTrace();
                response.sendRedirect(request.getContextPath() + 
                    "/products?error=Ошибка загрузки товара: " + e.getMessage());
            } catch (NumberFormatException e) {
                response.sendRedirect(request.getContextPath() + 
                    "/products?error=Неверный ID товара");
            }
        } else {
            response.sendRedirect(request.getContextPath() + 
                "/products?error=ID товара не указан");
        }
    }
    
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        try {
            // Получаем данные из формы
            Long id = Long.parseLong(request.getParameter("id"));
            String name = request.getParameter("name");
            String size = request.getParameter("size");
            String weightStr = request.getParameter("weight");
            String manufacturerIdStr = request.getParameter("manufacturerId");
            
            // Создаем объект товара
            Product product = new Product();
            product.setId(id);
            product.setName(name);
            product.setSize(size);
            
            if (weightStr != null && !weightStr.trim().isEmpty()) {
                product.setWeight(Double.parseDouble(weightStr));
            }
            
            if (manufacturerIdStr != null && !manufacturerIdStr.trim().isEmpty()) {
                Long manufacturerId = Long.parseLong(manufacturerIdStr);
                product.setManufacturerId(manufacturerId);
                
                // Загружаем производителя для связи
                ManufacturerDbDAO manufacturerDao = new ManufacturerDbDAO();
                Manufacturer manufacturer = manufacturerDao.findById(manufacturerId);
                product.setManufacturer(manufacturer);
            }
            
            // Обновляем товар в БД
            ProductDbDAO productDao = new ProductDbDAO();
            productDao.update(product);
            
            response.sendRedirect(request.getContextPath() + 
                "/products?success=Товар успешно обновлен");
            
        } catch (DAOException e) {
            e.printStackTrace();
            response.sendRedirect(request.getContextPath() + 
                "/products?error=Ошибка обновления товара: " + e.getMessage());
        } catch (NumberFormatException e) {
            response.sendRedirect(request.getContextPath() + 
                "/products?error=Неверные данные в форме");
        } catch (Exception e) {
            e.printStackTrace();
            response.sendRedirect(request.getContextPath() + 
                "/products?error=Неизвестная ошибка: " + e.getMessage());
        }
    }
}