<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<%@ taglib prefix="c" uri="jakarta.tags.core"%>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Редактирование товара</title>
    <link rel="stylesheet" href="${pageContext.request.contextPath}/css/bootstrap.min.css">
    <style>
        .form-container {
            max-width: 600px;
            margin: 30px auto;
            padding: 20px;
            border: 1px solid #ddd;
            border-radius: 8px;
            background-color: #f9f9f9;
        }
        .form-header {
            background-color: #007bff;
            color: white;
            padding: 15px;
            border-radius: 5px 5px 0 0;
            margin: -20px -20px 20px -20px;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="form-container">
            <div class="form-header">
                <h4 class="mb-0">Редактирование товара</h4>
                <small>ID: ${product.id}</small>
            </div>
            
            <!-- Сообщения об успехе/ошибке -->
            <c:if test="${not empty success}">
                <div class="alert alert-success alert-dismissible fade show">
                    ${success}
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
            </c:if>
            <c:if test="${not empty error}">
                <div class="alert alert-danger alert-dismissible fade show">
                    ${error}
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
            </c:if>
            
            <!-- Форма редактирования -->
            <form method="POST" action="${pageContext.request.contextPath}/editProduct">
                <input type="hidden" name="id" value="${product.id}">
                
                <div class="mb-3">
                    <label for="name" class="form-label">Наименование товара *</label>
                    <input type="text" class="form-control" id="name" 
                           name="name" value="${product.name}" required
                           placeholder="Введите название товара">
                </div>
                
                <div class="mb-3">
                    <label for="size" class="form-label">Размер</label>
                    <input type="text" class="form-control" id="size" 
                           name="size" value="${product.size}"
                           placeholder="Например: 15 дюймов, средний">
                </div>
                
                <div class="mb-3">
                    <label for="weight" class="form-label">Вес (кг)</label>
                    <input type="number" step="0.01" class="form-control" id="weight" 
                           name="weight" value="${product.weight}"
                           placeholder="Например: 2.5">
                </div>
                
                <div class="mb-3">
                    <label for="manufacturerId" class="form-label">Производитель</label>
                    <select name="manufacturerId" class="form-control" id="manufacturerId">
                        <option value="">-- Выберите производителя --</option>
                        <c:forEach var="manufacturer" items="${manufacturers}">
                            <option value="${manufacturer.id}"
                                <c:if test="${product.manufacturerId == manufacturer.id}">
                                    selected
                                </c:if>
                            >
                                ${manufacturer.name} (${manufacturer.country})
                            </option>
                        </c:forEach>
                    </select>
                    <c:if test="${not empty product.manufacturer}">
                        <small class="text-muted">
                            Текущий: ${product.manufacturer.name}
                        </small>
                    </c:if>
                </div>
                
                <div class="d-flex justify-content-between mt-4">
                    <a href="${pageContext.request.contextPath}/products" 
                       class="btn btn-secondary">
                        ← Назад к списку
                    </a>
                    <div>
                        <button type="submit" class="btn btn-primary">
                            💾 Сохранить изменения
                        </button>
                    </div>
                </div>
            </form>
            
            <!-- Дополнительная информация -->
            <div class="mt-4 pt-3 border-top">
                <h6>Информация о товаре:</h6>
                <ul class="list-unstyled">
                    <li><strong>ID:</strong> ${product.id}</li>
                    <c:if test="${not empty product.manufacturer}">
                        <li><strong>Текущий производитель:</strong> 
                            ${product.manufacturer.name} (${product.manufacturer.country})
                        </li>
                    </c:if>
                    <li><strong>Размер:</strong> 
                        <c:choose>
                            <c:when test="${not empty product.size}">${product.size}</c:when>
                            <c:otherwise>не указан</c:otherwise>
                        </c:choose>
                    </li>
                    <li><strong>Вес:</strong> 
                        <c:choose>
                            <c:when test="${not empty product.weight}">${product.weight} кг</c:when>
                            <c:otherwise>не указан</c:otherwise>
                        </c:choose>
                    </li>
                </ul>
            </div>
        </div>
    </div>
    
    <!-- Bootstrap JS -->
    <script src="${pageContext.request.contextPath}/js/jquery-3.6.4.js"></script>
    <script src="${pageContext.request.contextPath}/js/bootstrap.bundle.min.js"></script>
    
    <script>
        // Подтверждение формы
        document.querySelector('form').addEventListener('submit', function(e) {
            const name = document.getElementById('name').value.trim();
            if (!name) {
                e.preventDefault();
                alert('Пожалуйста, введите название товара');
                return false;
            }
            return true;
        });
    </script>
</body>
</html>