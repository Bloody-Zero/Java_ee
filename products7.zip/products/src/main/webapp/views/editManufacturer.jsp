<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<%@ taglib prefix="c" uri="jakarta.tags.core"%>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Редактирование производителя</title>
    <link rel="stylesheet" href="${pageContext.request.contextPath}/css/bootstrap.min.css">
</head>
<body>
    <div class="container mt-4">
        <div class="row">
            <div class="col-md-6 offset-md-3">
                <div class="card">
                    <div class="card-header bg-primary text-white">
                        <h4>Редактирование производителя</h4>
                    </div>
                    <div class="card-body">
                        <!-- Сообщения -->
                        <c:if test="${not empty success}">
                            <div class="alert alert-success">${success}</div>
                        </c:if>
                        <c:if test="${not empty error}">
                            <div class="alert alert-danger">${error}</div>
                        </c:if>
                        
                        <!-- Форма -->
                        <form method="POST" action="${pageContext.request.contextPath}/editManufacturer">
                            <input type="hidden" name="id" value="${manufacturer.id}">
                            
                            <div class="mb-3">
                                <label for="name" class="form-label">Название *</label>
                                <input type="text" class="form-control" id="name" 
                                       name="name" value="${manufacturer.name}" required>
                            </div>
                            
                            <div class="mb-3">
                                <label for="country" class="form-label">Страна *</label>
                                <input type="text" class="form-control" id="country" 
                                       name="country" value="${manufacturer.country}" required>
                            </div>
                            
                            <div class="mb-3">
                                <label for="contactPerson" class="form-label">Контактное лицо</label>
                                <input type="text" class="form-control" id="contactPerson" 
                                       name="contactPerson" value="${manufacturer.contactPerson}">
                            </div>
                            
                            <div class="mb-3">
                                <label for="phone" class="form-label">Телефон</label>
                                <input type="text" class="form-control" id="phone" 
                                       name="phone" value="${manufacturer.phone}">
                            </div>
                            
                            <div class="d-flex justify-content-between">
                                <a href="${pageContext.request.contextPath}/manufacturers" 
                                   class="btn btn-secondary">Назад</a>
                                <button type="submit" class="btn btn-primary">Сохранить</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <script src="${pageContext.request.contextPath}/js/jquery-3.6.4.js"></script>
    <script src="${pageContext.request.contextPath}/js/bootstrap.bundle.min.js"></script>
</body>
</html>