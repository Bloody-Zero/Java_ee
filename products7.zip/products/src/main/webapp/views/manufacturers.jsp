<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<%@ taglib prefix="c" uri="jakarta.tags.core"%>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Производители</title>
    <link rel="stylesheet" href="${pageContext.request.contextPath}/css/bootstrap.min.css">
</head>
<body>
    <div class="container-fluid">
        <jsp:include page="/views/header.jsp" />
        <div class="container-fluid">
            <div class="row justify-content-start">
                <div class="col-8 border bg-light px-4">
                    <h3>Список производителей</h3>
                    
                    <c:if test="${not empty error}">
                        <div class="alert alert-danger">${error}</div>
                    </c:if>
                    
                    <table class="table">
                        <thead>
                            <tr>
                                <th scope="col">Код</th>
                                <th scope="col">Название</th>
                                <th scope="col">Страна</th>
                                <th scope="col">Контактное лицо</th>
                                <th scope="col">Телефон</th>
                                <th scope="col">Редактировать</th>
                                <th scope="col">Удалить</th>
                            </tr>
                        </thead>
                        <tbody>
                            <c:forEach var="manufacturer" items="${manufacturers}">
                                <tr>
                                    <td>${manufacturer.id}</td>
                                    <td>${manufacturer.name}</td>
                                    <td>${manufacturer.country}</td>
                                    <td>${manufacturer.contactPerson}</td>
                                    <td>${manufacturer.phone}</td>
                          <td>
    <!-- Кнопка редактирования -->
    <a href="${pageContext.request.contextPath}/editManufacturer?id=${manufacturer.id}" 
       role="button" class="btn btn-outline-primary btn-sm p-1">
        <img alt="Редактировать" 
             src="${pageContext.request.contextPath}/images/icon-edit.png"
             width="18" height="18">
    </a>
</td>
<td>
    <!-- Кнопка удаления -->
    <a href="${pageContext.request.contextPath}/deleteManufacturer?id=${manufacturer.id}" 
       role="button" class="btn btn-outline-danger btn-sm p-1"
       onclick="return confirm('Удалить производителя ${manufacturer.name}?')">
        <img alt="Удалить" 
             src="${pageContext.request.contextPath}/images/icon-delete.png"
             width="18" height="18">
    </a>
</td>
                                </tr>
                            </c:forEach>
                            
                            <c:if test="${empty manufacturers}">
                                <tr>
                                    <td colspan="7" class="text-center">Нет производителей для отображения</td>
                                </tr>
                            </c:if>
                        </tbody>
                    </table>
                </div>
                
                <!-- Форма добавления -->
                <div class="col-4 border px-4">
                    <form method="POST" action="${pageContext.request.contextPath}/manufacturers">
                        <h3>Новый производитель</h3>
                        <div class="mb-3">
                            <label for="inputName" class="form-label">Название</label>
                            <input type="text" name="name" class="form-control" id="inputName" required>
                        </div>
                        <div class="mb-3">
                            <label for="inputCountry" class="form-label">Страна</label>
                            <input type="text" name="country" class="form-control" id="inputCountry" required>
                        </div>
                        <div class="mb-3">
                            <label for="inputContactPerson" class="form-label">Контактное лицо</label>
                            <input type="text" name="contactPerson" class="form-control" id="inputContactPerson">
                        </div>
                        <div class="mb-3">
                            <label for="inputPhone" class="form-label">Телефон</label>
                            <input type="text" name="phone" class="form-control" id="inputPhone">
                        </div>
                        <button type="submit" class="btn btn-primary">Добавить</button>
                    </form>
                </div>
            </div>
        </div>
        <jsp:include page="/views/footer.jsp" />
    </div>

    <script src="${pageContext.request.contextPath}/js/jquery-3.6.4.js"></script>
    <script src="${pageContext.request.contextPath}/js/bootstrap.bundle.min.js"></script>
</body>
</html>