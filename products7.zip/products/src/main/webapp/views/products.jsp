<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<%@ taglib prefix="c" uri="jakarta.tags.core"%>
<!-- УДАЛИТЬ импорты классов domain, они не нужны здесь -->
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Товары</title>
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="${pageContext.request.contextPath}/css/bootstrap.min.css">
</head>
<body>
    <div class="container-fluid">
        <jsp:include page="/views/header.jsp" />
        <div class="container-fluid">
            <div class="row justify-content-start">
                <!-- Список товаров -->
                <div class="col-8 border bg-light px-4">
                    <h3>Список товаров</h3>
                    
                    <!-- Проверка на наличие ошибки -->
                    <c:if test="${not empty error}">
                        <div class="alert alert-danger">${error}</div>
                    </c:if>
                    
                    <table class="table">
                        <thead>
                            <tr>
                                <th scope="col">Код</th>
                                <th scope="col">Наименование</th>
                                <th scope="col">Размер</th>
                                <th scope="col">Вес (кг)</th>
                                <th scope="col">Производитель</th>
                                <th scope="col">Редактировать</th>
                                <th scope="col">Удалить</th>
                            </tr>
                        </thead>
                        <tbody>
                            <!-- Используем JSTL forEach -->
                            <c:forEach var="product" items="${products}">
                                <tr>
                                    <td>${product.id}</td>
                                    <td>${product.name}</td>
                                    <td>${product.size}</td>
                                    <td>${product.weight}</td>
                                    <td>
                                        <c:choose>
                                            <c:when test="${not empty product.manufacturer}">
                                                ${product.manufacturer.name}
                                            </c:when>
                                            <c:otherwise>
                                                Не указан
                                            </c:otherwise>
                                        </c:choose>
                                    </td>
                                  <td>
    <!-- Кнопка редактирования -->
<td>
    <!-- Кнопка редактирования -->
    <a href="${pageContext.request.contextPath}/editProduct?id=${product.id}" 
       role="button" class="btn btn-outline-primary btn-sm p-1"
       title="Редактировать товар">
        <img alt="Редактировать" 
             src="${pageContext.request.contextPath}/images/icon-edit.png"
             width="18" height="18">
    </a>
</td>
</td>
<td>
    <!-- Кнопка удаления -->
    <a href="${pageContext.request.contextPath}/deleteProduct?id=${product.id}" 
       role="button" class="btn btn-outline-danger btn-sm p-1"
       onclick="return confirm('Удалить товар ${product.name}?')">
        <img alt="Удалить" 
             src="${pageContext.request.contextPath}/images/icon-delete.png"
             width="18" height="18">
    </a>
</td>
                                </tr>
                            </c:forEach>
                            
                            <!-- Если список пуст -->
                            <c:if test="${empty products}">
                                <tr>
                                    <td colspan="7" class="text-center">Нет товаров для отображения</td>
                                </tr>
                            </c:if>
                        </tbody>
                    </table>
                </div>
                
                <!-- Форма добавления нового товара -->
                <div class="col-4 border px-4">
                    <form method="POST" action="${pageContext.request.contextPath}/products">
                        <h3>Новый товар</h3>
                        <div class="mb-3">
                            <label for="inputName" class="form-label">Наименование</label>
                            <input type="text" name="name" class="form-control" id="inputName" required>
                        </div>
                        <div class="mb-3">
                            <label for="inputSize" class="form-label">Размер</label>
                            <input type="text" name="size" class="form-control" id="inputSize">
                        </div>
                        <div class="mb-3">
                            <label for="inputWeight" class="form-label">Вес (кг)</label>
                            <input type="number" step="0.01" name="weight" class="form-control" id="inputWeight">
                        </div>
                        <div class="mb-3">
                            <label for="inputManufacturer" class="form-label">Производитель</label>
                            <select name="manufacturerId" class="form-control" id="inputManufacturer">
                                <option value="">Выберите производителя</option>
                                <c:forEach var="manufacturer" items="${manufacturers}">
                                    <option value="${manufacturer.id}">
                                        ${manufacturer.name} (${manufacturer.country})
                                    </option>
                                </c:forEach>
                            </select>
                        </div>
                        <button type="submit" class="btn btn-primary">Добавить</button>
                    </form>
                </div>
            </div>
        </div>
        <jsp:include page="/views/footer.jsp" />
    </div>

    <!-- jQuery и Bootstrap JS -->
    <script src="${pageContext.request.contextPath}/js/jquery-3.6.4.js"></script>
    <script src="${pageContext.request.contextPath}/js/bootstrap.bundle.min.js"></script>
</body>
</html>