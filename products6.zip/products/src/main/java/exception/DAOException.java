package exception;

public class DAOException extends Exception {
    private static final long serialVersionUID = 1L;
    
    // Конструктор по умолчанию
    public DAOException() {
        super();
    }
    
    // Конструктор с сообщением
    public DAOException(String message) {
        super(message);
    }
    
    // Конструктор с причиной
    public DAOException(Throwable cause) {
        super(cause);
    }
    
    // Конструктор с сообщением и причиной
    public DAOException(String message, Throwable cause) {
        super(message, cause);
    }
}