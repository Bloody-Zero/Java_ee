package dao;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import domain.Product;
import domain.Manufacturer;
import exception.DAOException;

public class ProductDbDAO implements RepositoryDAO<Product> {
    
    private static final String SELECT_ALL = "SELECT p.id, p.name, p.size, p.weight, p.manufacturer_id, " +
                                           "m.name as manufacturer_name, m.country, m.contact_person, m.phone " +
                                           "FROM products p LEFT JOIN manufacturers m ON p.manufacturer_id = m.id " +
                                           "ORDER BY p.name";
    private static final String SELECT_BY_ID = "SELECT p.id, p.name, p.size, p.weight, p.manufacturer_id, " +
                                              "m.name as manufacturer_name, m.country, m.contact_person, m.phone " +
                                              "FROM products p LEFT JOIN manufacturers m ON p.manufacturer_id = m.id " +
                                              "WHERE p.id = ?";
    private static final String INSERT = "INSERT INTO products(name, size, weight, manufacturer_id) VALUES(?, ?, ?, ?)";
    private static final String UPDATE = "UPDATE products SET name=?, size=?, weight=?, manufacturer_id=? WHERE id=?";
    private static final String DELETE = "DELETE FROM products WHERE id=?";
    
    private ConnectionBuilder builder = new DbConnectionBuilder();
    
    private Connection getConnection() throws SQLException {
        return builder.getConnection();
    }
    
    @Override
    public Long insert(Product product) throws DAOException {
        try (Connection conn = getConnection();
             PreparedStatement pst = conn.prepareStatement(INSERT, Statement.RETURN_GENERATED_KEYS)) {
            
            pst.setString(1, product.getName());
            pst.setString(2, product.getSize());
            pst.setDouble(3, product.getWeight());
            pst.setLong(4, product.getManufacturerId());
            pst.executeUpdate();
            
            ResultSet rs = pst.getGeneratedKeys();
            if (rs.next()) {
                return rs.getLong(1);
            }
        } catch (SQLException e) {
            throw new DAOException(e);
        }
        return -1L;
    }
    
    @Override
    public void update(Product product) throws DAOException {
        try (Connection conn = getConnection();
             PreparedStatement pst = conn.prepareStatement(UPDATE)) {
            
            pst.setString(1, product.getName());
            pst.setString(2, product.getSize());
            pst.setDouble(3, product.getWeight());
            pst.setLong(4, product.getManufacturerId());
            pst.setLong(5, product.getId());
            pst.executeUpdate();
            
        } catch (SQLException e) {
            throw new DAOException(e);
        }
    }
    
    @Override
    public void delete(Long id) throws DAOException {
        try (Connection conn = getConnection();
             PreparedStatement pst = conn.prepareStatement(DELETE)) {
            
            pst.setLong(1, id);
            pst.executeUpdate();
            
        } catch (SQLException e) {
            throw new DAOException(e);
        }
    }
    
    @Override
    public Product findById(Long id) throws DAOException {
        Product product = null;
        try (Connection conn = getConnection();
             PreparedStatement pst = conn.prepareStatement(SELECT_BY_ID)) {
            
            pst.setLong(1, id);
            ResultSet rs = pst.executeQuery();
            
            if (rs.next()) {
                product = fillProduct(rs);
            }
            rs.close();
            
        } catch (SQLException e) {
            throw new DAOException(e);
        }
        return product;
    }
    
    @Override
    public List<Product> findAll() throws DAOException {
        List<Product> products = new ArrayList<>();
        try (Connection conn = getConnection();
             PreparedStatement pst = conn.prepareStatement(SELECT_ALL);
             ResultSet rs = pst.executeQuery()) {
            
            while (rs.next()) {
                products.add(fillProduct(rs));
            }
            
        } catch (SQLException e) {
            throw new DAOException(e);
        }
        return products;
    }
    
    private Product fillProduct(ResultSet rs) throws SQLException {
        Product product = new Product();
        product.setId(rs.getLong("id"));
        product.setName(rs.getString("name"));
        product.setSize(rs.getString("size"));
        product.setWeight(rs.getDouble("weight"));
        product.setManufacturerId(rs.getLong("manufacturer_id"));
        
        // Создаем объект Manufacturer, если есть данные
        if (rs.getString("manufacturer_name") != null) {
            Manufacturer manufacturer = new Manufacturer();
            manufacturer.setId(rs.getLong("manufacturer_id"));
            manufacturer.setName(rs.getString("manufacturer_name"));
            manufacturer.setCountry(rs.getString("country"));
            manufacturer.setContactPerson(rs.getString("contact_person"));
            manufacturer.setPhone(rs.getString("phone"));
            product.setManufacturer(manufacturer);
        }
        
        return product;
    }
}