package dao;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import domain.Manufacturer;
import exception.DAOException;

public class ManufacturerDbDAO implements RepositoryDAO<Manufacturer> {
    
    private static final String SELECT_ALL = "SELECT id, name, country, contact_person, phone FROM manufacturers ORDER BY name";
    private static final String SELECT_BY_ID = "SELECT id, name, country, contact_person, phone FROM manufacturers WHERE id = ?";
    private static final String INSERT = "INSERT INTO manufacturers(name, country, contact_person, phone) VALUES(?, ?, ?, ?)";
    private static final String UPDATE = "UPDATE manufacturers SET name=?, country=?, contact_person=?, phone=? WHERE id=?";
    private static final String DELETE = "DELETE FROM manufacturers WHERE id=?";
    
    private ConnectionBuilder builder = new DbConnectionBuilder();
    
    private Connection getConnection() throws SQLException {
        return builder.getConnection();
    }
    
    @Override
    public Long insert(Manufacturer manufacturer) throws DAOException {
        try (Connection conn = getConnection();
             PreparedStatement pst = conn.prepareStatement(INSERT, Statement.RETURN_GENERATED_KEYS)) {
            
            pst.setString(1, manufacturer.getName());
            pst.setString(2, manufacturer.getCountry());
            pst.setString(3, manufacturer.getContactPerson());
            pst.setString(4, manufacturer.getPhone());
            pst.executeUpdate();
            
            ResultSet rs = pst.getGeneratedKeys();
            if (rs.next()) {
                return rs.getLong(1);
            }
        } catch (SQLException e) {
            throw new DAOException(e);
        }
        return -1L;
    }
    
    @Override
    public void update(Manufacturer manufacturer) throws DAOException {
        try (Connection conn = getConnection();
             PreparedStatement pst = conn.prepareStatement(UPDATE)) {
            
            pst.setString(1, manufacturer.getName());
            pst.setString(2, manufacturer.getCountry());
            pst.setString(3, manufacturer.getContactPerson());
            pst.setString(4, manufacturer.getPhone());
            pst.setLong(5, manufacturer.getId());
            pst.executeUpdate();
            
        } catch (SQLException e) {
            throw new DAOException(e);
        }
    }
    
    @Override
    public void delete(Long id) throws DAOException {
        try (Connection conn = getConnection();
             PreparedStatement pst = conn.prepareStatement(DELETE)) {
            
            pst.setLong(1, id);
            pst.executeUpdate();
            
        } catch (SQLException e) {
            throw new DAOException(e);
        }
    }
    
    @Override
    public Manufacturer findById(Long id) throws DAOException {
        Manufacturer manufacturer = null;
        try (Connection conn = getConnection();
             PreparedStatement pst = conn.prepareStatement(SELECT_BY_ID)) {
            
            pst.setLong(1, id);
            ResultSet rs = pst.executeQuery();
            
            if (rs.next()) {
                manufacturer = fillManufacturer(rs);
            }
            rs.close();
            
        } catch (SQLException e) {
            throw new DAOException(e);
        }
        return manufacturer;
    }
    
    @Override
    public List<Manufacturer> findAll() throws DAOException {
        List<Manufacturer> manufacturers = new ArrayList<>();
        try (Connection conn = getConnection();
             PreparedStatement pst = conn.prepareStatement(SELECT_ALL);
             ResultSet rs = pst.executeQuery()) {
            
            while (rs.next()) {
                manufacturers.add(fillManufacturer(rs));
            }
            
        } catch (SQLException e) {
            throw new DAOException(e);
        }
        return manufacturers;
    }
    
    private Manufacturer fillManufacturer(ResultSet rs) throws SQLException {
        Manufacturer manufacturer = new Manufacturer();
        manufacturer.setId(rs.getLong("id"));
        manufacturer.setName(rs.getString("name"));
        manufacturer.setCountry(rs.getString("country"));
        manufacturer.setContactPerson(rs.getString("contact_person"));
        manufacturer.setPhone(rs.getString("phone"));
        return manufacturer;
    }
    
    // Метод для поиска производителя в коллекции по ID
    public Manufacturer findById(Long id, List<Manufacturer> manufacturers) {
        if (manufacturers != null) {
            for (Manufacturer m : manufacturers) {
                if (m.getId().equals(id)) {
                    return m;
                }
            }
        }
        return null;
    }
}