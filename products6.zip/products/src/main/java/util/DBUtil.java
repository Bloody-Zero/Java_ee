package util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.sql.SQLException;

/**
 * Утилита для тестирования подключения к базе данных
 */
public class DBUtil {
    
    /**
     * Тестирует подключение к БД и выводит информацию в консоль
     */
    public static void testConnection() {
        System.out.println("\n=== ТЕСТ ПОДКЛЮЧЕНИЯ К БД ===");
        
        // Параметры подключения (должны совпадать с config.properties)
        String url = "jdbc:postgresql://localhost:5432/products";
        String user = "postgres";
        String password = "ваш_пароль"; // ЗАМЕНИТЕ на ваш реальный пароль
        
        Connection conn = null;
        Statement stmt = null;
        ResultSet rs = null;
        
        try {
            // 1. Загружаем драйвер
            Class.forName("org.postgresql.Driver");
            System.out.println("✅ Драйвер PostgreSQL загружен");
            
            // 2. Пытаемся подключиться
            System.out.println("Попытка подключения к: " + url);
            conn = DriverManager.getConnection(url, user, password);
            System.out.println("✅ Подключение к БД УСПЕШНО!");
            
            // 3. Проверяем версию PostgreSQL
            stmt = conn.createStatement();
            rs = stmt.executeQuery("SELECT version()");
            if (rs.next()) {
                System.out.println("Версия PostgreSQL: " + rs.getString(1));
            }
            rs.close();
            
            // 4. Проверяем существование таблиц
            System.out.println("\n--- Проверка таблиц ---");
            
            // Таблица manufacturers
            rs = stmt.executeQuery(
                "SELECT EXISTS (SELECT FROM information_schema.tables " +
                "WHERE table_schema = 'public' AND table_name = 'manufacturers')"
            );
            if (rs.next()) {
                boolean exists = rs.getBoolean(1);
                System.out.println("Таблица 'manufacturers' существует: " + exists);
            }
            rs.close();
            
            // Таблица products
            rs = stmt.executeQuery(
                "SELECT EXISTS (SELECT FROM information_schema.tables " +
                "WHERE table_schema = 'public' AND table_name = 'products')"
            );
            if (rs.next()) {
                boolean exists = rs.getBoolean(1);
                System.out.println("Таблица 'products' существует: " + exists);
            }
            rs.close();
            
            // 5. Считаем записи в таблицах
            System.out.println("\n--- Количество записей ---");
            
            // Manufacturers
            rs = stmt.executeQuery("SELECT COUNT(*) as count FROM manufacturers");
            if (rs.next()) {
                int count = rs.getInt("count");
                System.out.println("Производителей в БД: " + count);
                
                // Если есть записи, выводим первые 5
                if (count > 0) {
                    ResultSet rsData = stmt.executeQuery(
                        "SELECT id, name, country FROM manufacturers LIMIT 5"
                    );
                    System.out.println("Первые производители:");
                    while (rsData.next()) {
                        System.out.println("  - ID: " + rsData.getInt("id") + 
                                         ", Название: " + rsData.getString("name") +
                                         ", Страна: " + rsData.getString("country"));
                    }
                    rsData.close();
                }
            }
            rs.close();
            
            // Products
            rs = stmt.executeQuery("SELECT COUNT(*) as count FROM products");
            if (rs.next()) {
                int count = rs.getInt("count");
                System.out.println("Товаров в БД: " + count);
                
                // Если есть записи, выводим первые 5
                if (count > 0) {
                    ResultSet rsData = stmt.executeQuery(
                        "SELECT p.id, p.name, p.size, m.name as manufacturer_name " +
                        "FROM products p LEFT JOIN manufacturers m ON p.manufacturer_id = m.id " +
                        "LIMIT 5"
                    );
                    System.out.println("Первые товары:");
                    while (rsData.next()) {
                        System.out.println("  - ID: " + rsData.getInt("id") + 
                                         ", Название: " + rsData.getString("name") +
                                         ", Размер: " + rsData.getString("size") +
                                         ", Производитель: " + rsData.getString("manufacturer_name"));
                    }
                    rsData.close();
                }
            }
            rs.close();
            
            System.out.println("\n=== ТЕСТ ЗАВЕРШЕН УСПЕШНО ===");
            
        } catch (ClassNotFoundException e) {
            System.err.println("❌ Драйвер PostgreSQL не найден!");
            System.err.println("Убедитесь, что postgresql-*.jar в папке WEB-INF/lib/");
            e.printStackTrace();
            
        } catch (SQLException e) {
            System.err.println("❌ Ошибка SQL: " + e.getMessage());
            System.err.println("Код ошибки: " + e.getErrorCode());
            System.err.println("Состояние SQL: " + e.getSQLState());
            e.printStackTrace();
            
        } catch (Exception e) {
            System.err.println("❌ Неожиданная ошибка: " + e.getMessage());
            e.printStackTrace();
            
        } finally {
            // Закрываем ресурсы
            try { if (rs != null) rs.close(); } catch (SQLException e) { /* игнорируем */ }
            try { if (stmt != null) stmt.close(); } catch (SQLException e) { /* игнорируем */ }
            try { if (conn != null) conn.close(); } catch (SQLException e) { /* игнорируем */ }
        }
    }
    
    /**
     * Альтернативный метод для тестирования с параметрами из config.properties
     */
    public static void testConnectionFromConfig() {
        System.out.println("\n=== ТЕСТ ПОДКЛЮЧЕНИЯ ИЗ CONFIG ===");
        
        try {
            // Пытаемся прочитать настройки так же, как это делает ConnectionProperty
            java.util.Properties prop = new java.util.Properties();
            java.io.InputStream input = DBUtil.class.getClassLoader()
                .getResourceAsStream("config/config.properties");
            
            if (input == null) {
                System.err.println("❌ Файл config.properties не найден!");
                System.err.println("Искали по пути: config/config.properties");
                return;
            }
            
            prop.load(input);
            input.close();
            
            String url = prop.getProperty("db.url");
            String user = prop.getProperty("db.login");
            String password = prop.getProperty("db.password");
            
            System.out.println("Прочитано из config.properties:");
            System.out.println("URL: " + url);
            System.out.println("User: " + user);
            System.out.println("Password: " + (password != null ? "***" : "NULL"));
            
            // Тестируем с этими параметрами
            if (url != null && user != null && password != null) {
                testConnection(url, user, password);
            } else {
                System.err.println("❌ Не все параметры найдены в config.properties");
            }
            
        } catch (Exception e) {
            System.err.println("❌ Ошибка чтения config.properties: " + e.getMessage());
            e.printStackTrace();
        }
    }
    
    private static void testConnection(String url, String user, String password) {
        try {
            Class.forName("org.postgresql.Driver");
            Connection conn = DriverManager.getConnection(url, user, password);
            System.out.println("✅ Подключение из config.properties УСПЕШНО!");
            conn.close();
        } catch (Exception e) {
            System.err.println("❌ Ошибка подключения: " + e.getMessage());
        }
    }
    
    /**
     * Основной метод для запуска теста из командной строки
     */
    public static void main(String[] args) {
        System.out.println("Запуск теста подключения к БД...");
        testConnection();
        // testConnectionFromConfig(); // Раскомментируйте, чтобы протестировать чтение config
    }
}